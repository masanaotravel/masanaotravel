import React from 'react';
import styles from './ToursPage.module.css';

const tours = [
  {
    title: "Paris Highlights",
    img: "/images/paris.jpg",
    description: "Experience the romance and beauty of Paris. 5 days, 4 nights from $999.",
  },
  {
    title: "Bali Adventure",
    img: "/images/bali.jpg",
    description: "Relax on tropical beaches and explore local culture. 7 days, 6 nights from $1,299.",
  },
  {
    title: "Japan Explorer",
    img: "/images/japan.jpg",
    description: "Discover ancient temples and modern cities. 8 days, 7 nights from $1,499.",
  },
];

export default function ToursPage() {
  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <h1>Masanao Travel Agency</h1>
        <nav>
          <a href="/">Home</a>
          <a href="/tours">Tours</a>
          <a href="/about">About</a>
          <a href="/contact">Contact</a>
        </nav>
      </header>
      <main>
        <h2>Our Tours</h2>
        <div className={styles.toursList}>
          {tours.map(tour => (
            <div className={styles.tourCard} key={tour.title}>
              <img src={tour.img} alt={tour.title} />
              <h4>{tour.title}</h4>
              <p>{tour.description}</p>
            </div>
          ))}
        </div>
      </main>
      <footer className={styles.footer}>
        &copy; 2025 Masanao Travel Agency. All rights reserved.
      </footer>
    </div>
  );
}